#!/usr/bin/perl
# Call mtr in out-of-source build
$ENV{MTR_BINDIR} = 'D:/MyFile/mysql-src/mysql-make2';
chdir('D:/MyFile/mysql-src/mysql-5.7.20/mysql-test');
exit(system($^X, 'D:/MyFile/mysql-src/mysql-5.7.20/mysql-test/mysql-test-run.pl', @ARGV) >> 8);
